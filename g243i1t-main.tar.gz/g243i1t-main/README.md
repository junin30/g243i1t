# Leonardo - 25
# Vinicius - 34